<html>

<body>
    <div id=':1fn' class='a3s adM' style='overflow: hidden;'>
        <div class='HOEnZb'>
            <div class='adm'>
                <div id='q_152da6db6beee01c_0' class='ajR h4' data-tooltip='Hide expanded content' aria-label='Hide expanded content'>
                    <div class='ajT'></div>
                </div>
            </div>
            <div class='im'>
                <u></u>
                <div style='margin:0'>

                    <u></u>
                    <div style='margin:0 auto;width:90%'>
                        <div style='margin:50px auto;width:80%'>
                            <div align='center'>
                                <img src='http://admin.findacross.com/assets/img/find.png' alt='Findacross' class='CToWUd'>
                            </div>
                            <p style='color:#000;font-family:Roboto;font-size:20px'>Dear
                                <span style='color:#000;font-family:Roboto;font-size:20px'>
                                    <?php echo $bid; ?>
                                </span>,</p>

                            <p style='color:#000;font-family:Roboto;font-size:20px'>You have new Enquiry From:
                                <?php echo $name; ?>
                            </p>
                            
							<table>
							<tr>
							<td>Email</td>
							<td> : </td>
							<td><?php echo $email; ?></td>
							</tr>
							<tr>
							<td>Contact No.</td>
							<td> : </td>
							<td> <?php echo $contact; ?></td>
							</tr>
							<tr>
							<td>Message</td>
							<td> : </td>
							<td> <?php echo $message; ?></td>
							</tr>
							</table>
                            <p style='color:#000;font-family:Roboto;font-size:20px'>Stay tuned for latest news and updates from the team at Findacross.
                            </p>

                            <span style='color:#000;font-family:Roboto;font-size:20px'>Thank You,</span>
                            <span style='color:#000;display:block;font-family:Roboto;font-size:20px'>Team Findacross !</span>
                        </div>
                    </div>
                    <u></u>
                    <footer style='background:#133782;padding:10px 0'>
                        <div style='margin:0 auto;width:90%'>
                            <div>
                                <table align='center'>
                                    <tbody>
                                        <tr>
                                            <td style='padding:0 5px'>
                                                <div>
                                                    <span style='color:#c8c2c2;font-family:Roboto;font-size:12px'>COPYRIGHT@FINDACROSS@2018</span>
                                                </div>
                                            </td>
                                            <td style='padding:0 5px'>
                                                <div>
                                                    <span style='color:#c8c2c2;font-family:Roboto;font-size:12px'>CONTACT US
                                                        <a href='tel:8898-443344' style='color:#c8c2c2;font-family:Roboto;font-size:12px;margin:0px 10px;text-decoration:none' target='_blank'>+91 9702123923</a>
                                                    </span>
                                                </div>
                                            </td>

                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </footer>
                </div>


            </div>
        </div>
    </div>
</body>

</html>